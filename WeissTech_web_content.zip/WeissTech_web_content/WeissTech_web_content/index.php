<html>
<body>Welcome to my global website! <br>The Server you are seeing is named:</br>

<?php
echo gethostname();
?>
</body>
</html>
